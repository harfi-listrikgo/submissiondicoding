package com.example.harfinovian.submission1.presenter.match

import android.view.View

interface IMatchPresenter {
    fun getAllItemList(view: View, param: String)
}